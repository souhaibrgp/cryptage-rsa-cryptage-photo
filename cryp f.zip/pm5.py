import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from math import gcd
import random

# RSA Key Generation Arithmetic
def rsa_key_generation(p, q):
    if not is_prime(p) or not is_prime(q):
        messagebox.showerror("Error", "Both p and q must be prime numbers.")
        return None, None, None

    if p == q:
        messagebox.showerror("Error", "p and q must be different.")
        return None, None, None

    n = p * q
    phi_n = (p - 1) * (q - 1)

    e = 65537
    while gcd(e, phi_n) != 1:
        e = random.randint(2, phi_n - 1)

    d = mod_inverse(e, phi_n)

    return (e, n), (d, n)

def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        m, a = a % m, m
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += m0
    return x1

def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

def sieve_of_eratosthenes(min_number, max_number):
    sieve = [True] * (max_number + 1)
    sieve[0] = sieve[1] = False  # 0 and 1 are not prime numbers
    for start in range(2, int(max_number ** 0.5) + 1):
        if sieve[start]:
            for multiple in range(start * start, max_number + 1, start):
                sieve[multiple] = False
    primes = [num for num in range(min_number, max_number + 1) if sieve[num]]
    return primes

def get_random_prime(min_number, max_number):
    primes = sieve_of_eratosthenes(min_number, max_number)
    if not primes:
        raise ValueError(f"No primes found in the range {min_number} to {max_number}.")
    return random.choice(primes)

def encrypt_message(public_key, plaintext):
    e, n = public_key
    encrypted = [pow(ord(char), e, n) for char in plaintext]
    return ' '.join(map(str, encrypted))

def decrypt_message(private_key, ciphertext):
    d, n = private_key
    decrypted = ''.join([chr(pow(char, d, n)) for char in ciphertext])
    return decrypted

def caesar_encrypt(plaintext, shift):
    encrypted = ''.join([chr(((ord(char) - 65 + shift) % 26) + 65) if char.isupper()
                         else chr(((ord(char) - 97 + shift) % 26) + 97) if char.islower() else char
                         for char in plaintext])
    return encrypted

def caesar_decrypt(ciphertext, shift):
    return caesar_encrypt(ciphertext, -shift)

def vigenere_encrypt(plaintext, key):
    encrypted = []
    key_length = len(key)
    for i, char in enumerate(plaintext):
        if char.isupper():
            encrypted.append(chr((ord(char) + ord(key[i % key_length].upper()) - 2 * ord('A')) % 26 + ord('A')))
        elif char.islower():
            encrypted.append(chr((ord(char) + ord(key[i % key_length].lower()) - 2 * ord('a')) % 26 + ord('a')))
        else:
            encrypted.append(char)
    return ''.join(encrypted)

def vigenere_decrypt(ciphertext, key):
    decrypted = []
    key_length = len(key)
    for i, char in enumerate(ciphertext):
        if char.isupper():
            decrypted.append(chr((ord(char) - ord(key[i % key_length].upper()) + 26) % 26 + ord('A')))
        elif char.islower():
            decrypted.append(chr((ord(char) - ord(key[i % key_length].lower()) + 26) % 26 + ord('a')))
        else:
            decrypted.append(char)
    return ''.join(decrypted)

def reset_rsa_tab():
    rsa_p_entry.delete(0, tk.END)
    rsa_q_entry.delete(0, tk.END)
    rsa_min_entry.delete(0, tk.END)
    rsa_max_entry.delete(0, tk.END)
    arithmetic_text.delete(1.0, tk.END)
    rsa_input_text.delete(0, tk.END)
    result_rsa_text.delete(1.0, tk.END)

def reset_caesar_tab():
    caesar_input_text.delete(0, tk.END)
    caesar_shift_entry.delete(0, tk.END)
    result_caesar_text.delete(1.0, tk.END)

def reset_vigenere_tab():
    vigenere_input_text.delete(0, tk.END)
    vigenere_key_entry.delete(0, tk.END)
    result_vigenere_text.delete(1.0, tk.END)

def on_rsa_generate_keys():
    global public_key, private_key

    try:
        p = int(rsa_p_entry.get())
        q = int(rsa_q_entry.get())
        public_key, private_key = rsa_key_generation(p, q)

        if public_key and private_key:
            rsa_arithmetic = {
                "p": p,
                "q": q,
                "n": public_key[1],
                "phi_n": (p - 1) * (q - 1),
                "e": public_key[0],
                "d": private_key[0]
            }

            arithmetic_text.delete(1.0, tk.END)
            arithmetic_text.insert(tk.END, f"Prime p: {rsa_arithmetic['p']}\n")
            arithmetic_text.insert(tk.END, f"Prime q: {rsa_arithmetic['q']}\n")
            arithmetic_text.insert(tk.END, f"Modulus n = p * q: {rsa_arithmetic['n']}\n")
            arithmetic_text.insert(tk.END, f"Euler's Totient ϕ(n): {rsa_arithmetic['phi_n']}\n")
            arithmetic_text.insert(tk.END, f"Public exponent e: {rsa_arithmetic['e']}\n")
            arithmetic_text.insert(tk.END, f"Private exponent d: {rsa_arithmetic['d']}\n")

            messagebox.showinfo("Info", "RSA Keys and Arithmetic Generated")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid integers for p and q.")

def generate_random_primes():
    try:
        min_number = int(rsa_min_entry.get())
        max_number = int(rsa_max_entry.get())

        if min_number >= max_number:
            messagebox.showerror("Error", "Minimum number must be less than maximum number.")
            return

        prime_1 = get_random_prime(min_number, max_number)
        prime_2 = get_random_prime(min_number, max_number)

        while prime_1 == prime_2:  # Ensure the primes are distinct
            prime_2 = get_random_prime(min_number, max_number)

        rsa_p_entry.delete(0, tk.END)
        rsa_p_entry.insert(0, str(prime_1))

        rsa_q_entry.delete(0, tk.END)
        rsa_q_entry.insert(0, str(prime_2))

        messagebox.showinfo("Info", f"Generated primes:\np: {prime_1}, q: {prime_2}")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid integers for min and max numbers.")

def on_rsa_encrypt():
    text = rsa_input_text.get()
    if not public_key:
        messagebox.showerror("Error", "Please generate RSA keys first")
        return
    encrypted = encrypt_message(public_key, text)
    result_rsa_text.delete(1.0, tk.END)
    result_rsa_text.insert(tk.END, encrypted)

def on_rsa_decrypt():
    text = rsa_input_text.get()
    if not private_key:
        messagebox.showerror("Error", "Please generate RSA keys first")
        return
    try:
        ciphertext = list(map(int, text.strip().split()))
        decrypted = decrypt_message(private_key, ciphertext)
        result_rsa_text.delete(1.0, tk.END)
        result_rsa_text.insert(tk.END, decrypted)
    except Exception as e:
        messagebox.showerror("Error", f"Decryption failed: {str(e)}")

def on_caesar_encrypt():
    text = caesar_input_text.get()
    shift = int(caesar_shift_entry.get())
    encrypted = caesar_encrypt(text, shift)
    result_caesar_text.delete(1.0, tk.END)
    result_caesar_text.insert(tk.END, encrypted)

def on_caesar_decrypt():
    text = caesar_input_text.get()
    shift = int(caesar_shift_entry.get())
    decrypted = caesar_decrypt(text, shift)
    result_caesar_text.delete(1.0, tk.END)
    result_caesar_text.insert(tk.END, decrypted)

def on_vigenere_encrypt():
    text = vigenere_input_text.get()
    key = vigenere_key_entry.get()
    encrypted = vigenere_encrypt(text, key)
    result_vigenere_text.delete(1.0, tk.END)
    result_vigenere_text.insert(tk.END, encrypted)

def on_vigenere_decrypt():
    text = vigenere_input_text.get()
    key = vigenere_key_entry.get()
    decrypted = vigenere_decrypt(text, key)
    result_vigenere_text.delete(1.0, tk.END)
    result_vigenere_text.insert(tk.END, decrypted)
# Functions for Caesar RSA
# Caesar + RSA Combined Functions
def caesar_rsa_encrypt():
    try:
        text = caesar_rsa_input_text.get()
        shift = int(caesar_rsa_shift_entry.get())
        
        # Step 1: Caesar Cipher Encryption
        caesar_encrypted = caesar_encrypt(text, shift)

        # Step 2: RSA Encryption (using default keys)
        e, n = 17, 323  # Example RSA keys (public key)
        rsa_encrypted = [str(pow(ord(char), e, n)) for char in caesar_encrypted]

        result_caesar_rsa_text.delete(1.0, tk.END)
        result_caesar_rsa_text.insert(tk.END, ' '.join(rsa_encrypted))
    except ValueError:
        messagebox.showerror("Error", "Invalid input. Ensure text and shift are correct.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

def caesar_rsa_decrypt():
    try:
        ciphertext = caesar_rsa_input_text.get().strip().split()
        shift = int(caesar_rsa_shift_entry.get())
        
        # Step 1: RSA Decryption
        d, n = 2753, 323  # Example RSA keys (private key)
        rsa_decrypted = ''.join(chr(pow(int(num), d, n)) for num in ciphertext)

        # Step 2: Caesar Cipher Decryption
        caesar_decrypted = caesar_decrypt(rsa_decrypted, shift)

        result_caesar_rsa_text.delete(1.0, tk.END)
        result_caesar_rsa_text.insert(tk.END, caesar_decrypted)
    except ValueError:
        messagebox.showerror("Error", "Invalid input. Ensure ciphertext and shift are correct.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

def reset_caesar_rsa_tab():
    caesar_rsa_input_text.delete(0, tk.END)
    caesar_rsa_shift_entry.delete(0, tk.END)
    result_caesar_rsa_text.delete(1.0, tk.END)

# Create main window
root = ctk.CTk()
root.title("Cryptographic Algorithms")
root.geometry("700x800")  # Wider window size
root.configure(bg="#1D3557")  # Very Dark Blue background

# Global variables
public_key, private_key = None, None

def toggle_theme():
    current_mode = ctk.get_appearance_mode()
    if current_mode == "Dark":
        ctk.set_appearance_mode("Light")
    else:
        ctk.set_appearance_mode("Dark")
# Create the tabbed notebook
notebook = ctk.CTkTabview(root, width=800, height=700)
notebook.pack(padx=10, pady=10, fill="both", expand=True)

# Create frames for different tabs
rsa_frame = notebook.add("RSA Encryption")
caesar_frame = notebook.add("Caesar Cipher")
vigenere_frame = notebook.add("Vigenère Cipher")
caesar_rsa_frame = notebook.add("Caesar + RSA")

# RSA Tab
rsa_min_max_purpose = ctk.CTkLabel(rsa_frame, text="Enter the range for generating random primes p and q:")
rsa_min_max_purpose.pack(pady=5)
rsa_range_frame = ctk.CTkFrame(rsa_frame)  # Frame to group Min and Max
rsa_range_frame.pack(pady=5)

rsa_min_label = ctk.CTkLabel(rsa_range_frame, text="Min:")
rsa_min_label.grid(row=0, column=0, padx=5)
rsa_min_entry = ctk.CTkEntry(rsa_range_frame, width=100)
rsa_min_entry.grid(row=0, column=1, padx=5)

rsa_max_label = ctk.CTkLabel(rsa_range_frame, text="Max:")
rsa_max_label.grid(row=0, column=2, padx=5)
rsa_max_entry = ctk.CTkEntry(rsa_range_frame, width=100)
rsa_max_entry.grid(row=0, column=3, padx=5)

generate_primes_button = ctk.CTkButton(rsa_frame, text="Generate Primes", command=generate_random_primes)
generate_primes_button.pack(pady=5)
rsa_rf = ctk.CTkFrame(rsa_frame)
rsa_rf.pack(pady=5)
rsa_p_label = ctk.CTkLabel(rsa_rf, text="Prime p:")
rsa_p_label.grid(row=1, column=0, padx=5)
rsa_p_entry = ctk.CTkEntry(rsa_rf, width=100)
rsa_p_entry.grid(row=1, column=1, padx=5)

rsa_q_label = ctk.CTkLabel(rsa_rf, text="Prime q:")
rsa_q_label.grid(row=1, column=2, padx=5)
rsa_q_entry = ctk.CTkEntry(rsa_rf, width=100)
rsa_q_entry.grid(row=1, column=3, padx=5)

generate_keys_button = ctk.CTkButton(rsa_frame, text="Generate Keys", command=on_rsa_generate_keys)
generate_keys_button.pack(pady=5)

arithmetic_text = ctk.CTkTextbox(rsa_frame, height=80, width=250)
arithmetic_text.pack(pady=5)

rsa_input_label = ctk.CTkLabel(rsa_frame, text="Input Text:")
rsa_input_label.pack(pady=5)
rsa_input_text = ctk.CTkEntry(rsa_frame,width=350)
rsa_input_text.pack(pady=5)

rsa_encrypt_button = ctk.CTkButton(rsa_frame, text="Encrypt", command=on_rsa_encrypt)
rsa_encrypt_button.pack(pady=5)

rsa_decrypt_button = ctk.CTkButton(rsa_frame, text="Decrypt", command=on_rsa_decrypt)
rsa_decrypt_button.pack(pady=5)

result_rsa_text = ctk.CTkTextbox(rsa_frame, height=50,width=250)
result_rsa_text.pack(pady=5)

reset_rsa_button = ctk.CTkButton(rsa_frame, text="Reset", command=reset_rsa_tab)
reset_rsa_button.pack(pady=5)

# Caesar Cipher Tab
caesar_input_label = ctk.CTkLabel(caesar_frame, text="Input Text:")
caesar_input_label.pack(pady=5)
caesar_input_text = ctk.CTkEntry(caesar_frame)
caesar_input_text.pack(pady=5)

caesar_shift_label = ctk.CTkLabel(caesar_frame, text="Shift:")
caesar_shift_label.pack(pady=5)
caesar_shift_entry = ctk.CTkEntry(caesar_frame)
caesar_shift_entry.pack(pady=5)

caesar_encrypt_button = ctk.CTkButton(caesar_frame, text="Encrypt", command=on_caesar_encrypt)
caesar_encrypt_button.pack(pady=5)

caesar_decrypt_button = ctk.CTkButton(caesar_frame, text="Decrypt", command=on_caesar_decrypt)
caesar_decrypt_button.pack(pady=5)

result_caesar_text = ctk.CTkTextbox(caesar_frame, height=100)
result_caesar_text.pack(pady=5)

reset_caesar_button = ctk.CTkButton(caesar_frame, text="Reset", command=reset_caesar_tab)
reset_caesar_button.pack(pady=5)

# Vigenère Cipher Tab
vigenere_input_label = ctk.CTkLabel(vigenere_frame, text="Input Text:")
vigenere_input_label.pack(pady=5)
vigenere_input_text = ctk.CTkEntry(vigenere_frame)
vigenere_input_text.pack(pady=5)

vigenere_key_label = ctk.CTkLabel(vigenere_frame, text="Key:")
vigenere_key_label.pack(pady=5)
vigenere_key_entry = ctk.CTkEntry(vigenere_frame)
vigenere_key_entry.pack(pady=5)

vigenere_encrypt_button = ctk.CTkButton(vigenere_frame, text="Encrypt", command=on_vigenere_encrypt)
vigenere_encrypt_button.pack(pady=5)

vigenere_decrypt_button = ctk.CTkButton(vigenere_frame, text="Decrypt", command=on_vigenere_decrypt)
vigenere_decrypt_button.pack(pady=5)

result_vigenere_text = ctk.CTkTextbox(vigenere_frame, height=100)
result_vigenere_text.pack(pady=5)

reset_vigenere_button = ctk.CTkButton(vigenere_frame, text="Reset", command=reset_vigenere_tab)
reset_vigenere_button.pack(pady=5)

# Caesar RSA Tab
caesar_rsa_input_label = ctk.CTkLabel(caesar_rsa_frame, text="Input Text:")
caesar_rsa_input_label.pack(pady=5)
caesar_rsa_input_text = ctk.CTkEntry(caesar_rsa_frame)
caesar_rsa_input_text.pack(pady=5)

caesar_rsa_shift_label = ctk.CTkLabel(caesar_rsa_frame, text="Shift:")
caesar_rsa_shift_label.pack(pady=5)
caesar_rsa_shift_entry = ctk.CTkEntry(caesar_rsa_frame)
caesar_rsa_shift_entry.pack(pady=5)

caesar_rsa_encrypt_button = ctk.CTkButton(caesar_rsa_frame, text="Encrypt", command=caesar_rsa_encrypt)
caesar_rsa_encrypt_button.pack(pady=5)

caesar_rsa_decrypt_button = ctk.CTkButton(caesar_rsa_frame, text="Decrypt", command=caesar_rsa_decrypt)
caesar_rsa_decrypt_button.pack(pady=5)

result_caesar_rsa_text = ctk.CTkTextbox(caesar_rsa_frame, height=100)
result_caesar_rsa_text.pack(pady=5)

reset_caesar_rsa_button = ctk.CTkButton(caesar_rsa_frame, text="Reset", command=reset_caesar_rsa_tab)
reset_caesar_rsa_button.pack(pady=5)

toggle_theme_button = ctk.CTkButton(root, text="Toggle Theme", command=toggle_theme)
toggle_theme_button.place(relx=0.98, rely=0.05, anchor="ne")
# Start the main loop
root.mainloop()