import tkinter as tk
from tkinter import messagebox
import math
import numpy as np
from sklearn.linear_model import LinearRegression

class PathComparisonApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Dijkstra vs ML Comparison")
        self.root.geometry("800x700")
        self.root.configure(bg="#161b22")

        # Canvas
        self.canvas = tk.Canvas(root, width=800, height=600, bg="#161b22", highlightthickness=0)
        self.canvas.pack()

        # Buttons
        button_frame = tk.Frame(root, bg="#161b22")
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Train ML", command=self.train_ml, bg="#1162e3", fg="white").pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Run Dijkstra", command=self.run_dijkstra, bg="#238636", fg="white").pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Run Hybrid", command=self.run_hybrid, bg="#f0a500", fg="black").pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Reset", command=self.reset, bg="#d73a49", fg="white").pack(side=tk.LEFT, padx=5)

        # Variables
        self.nodes = []
        self.edges = []
        self.start_node = None
        self.model = LinearRegression()
        self.trained = False
        self.drag_start_node = None

        # Bindings
        self.canvas.bind("<Button-1>", self.left_click_handler)
        self.canvas.bind("<B1-Motion>", self.start_edge_drag)
        self.canvas.bind("<ButtonRelease-1>", self.complete_edge_drag)

    def create_node(self, x, y):
        """Create a new node at the given location."""
        node_id = len(self.nodes) + 1
        node = {"id": node_id, "x": x, "y": y, "is_start": False}
        self.nodes.append(node)
        self.draw_node(node)

    def draw_node(self, node):
        """Draw a node on the canvas."""
        x, y = node["x"], node["y"]
        color = "green" if node.get("is_start", False) else "#58a6ff"
        self.canvas.create_oval(x - 20, y - 20, x + 20, y + 20, fill=color, outline="#c9d1d9", width=2, tags=f"node_{node['id']}")
        self.canvas.create_text(x, y, text=str(node["id"]), fill="white", font=("Arial", 12, "bold"))

    def draw_edge(self, edge, color="#8b949e", display_weight=True):
        """Draw an edge on the canvas."""
        x1, y1 = edge["start"]["x"], edge["start"]["y"]
        x2, y2 = edge["end"]["x"], edge["end"]["y"]
        self.canvas.create_line(x1, y1, x2, y2, fill=color, width=2, tags="edge")
        if display_weight:
            weight_x, weight_y = (x1 + x2) / 2, (y1 + y2) / 2
            self.canvas.create_text(weight_x, weight_y, text=f"{edge['weight']:.1f}", fill="#c9d1d9", font=("Arial", 10), tags="edge_weight")

    def is_inside_node(self, x, y, node):
        """Check if a point (x, y) is inside a node."""
        return math.sqrt((x - node["x"]) ** 2 + (y - node["y"]) ** 2) <= 20

    def get_node_at_position(self, x, y):
        """Get the node at a specific position."""
        for node in self.nodes:
            if self.is_inside_node(x, y, node):
                return node
        return None

    def left_click_handler(self, event):
        """Handle left-clicks for creating nodes or selecting start node."""
        x, y = event.x, event.y
        clicked_node = self.get_node_at_position(x, y)

        if clicked_node:
            # Set start node
            if self.start_node:
                self.start_node["is_start"] = False
                self.draw_node(self.start_node)

            self.start_node = clicked_node
            self.start_node["is_start"] = True
            self.draw_node(self.start_node)
        else:
            # Create a new node
            self.create_node(x, y)

    def start_edge_drag(self, event):
        """Start dragging to create an edge."""
        if not self.drag_start_node:
            self.drag_start_node = self.get_node_at_position(event.x, event.y)

    def complete_edge_drag(self, event):
        """Complete dragging to create an edge."""
        if self.drag_start_node:
            end_node = self.get_node_at_position(event.x, event.y)
            if end_node and end_node != self.drag_start_node:
                weight = math.sqrt(
                    (end_node["x"] - self.drag_start_node["x"]) ** 2 +
                    (end_node["y"] - self.drag_start_node["y"]) ** 2
                )
                edge = {"start": self.drag_start_node, "end": end_node, "weight": weight}
                self.edges.append(edge)
                self.draw_edge(edge)
            self.drag_start_node = None

    def train_ml(self):
        """Train a simple ML model to predict edge weights."""
        if not self.edges:
            messagebox.showerror("Error", "No edges to train on!")
            return

        X_train = []
        y_train = []

        for edge in self.edges:
            start, end = edge["start"], edge["end"]
            X_train.append([start["x"], start["y"], end["x"], end["y"]])
            y_train.append(edge["weight"])

        X_train = np.array(X_train)
        y_train = np.array(y_train)

        self.model.fit(X_train, y_train)
        self.trained = True
        messagebox.showinfo("Training Complete", "ML model trained successfully!")

    def run_dijkstra(self):
        """Run Dijkstra's algorithm to find shortest paths."""
        if not self.nodes:
            messagebox.showerror("Error", "No nodes available!")
            return

        if not self.start_node:
            messagebox.showerror("Error", "Set a start node first!")
            return

        self.canvas.delete("path")  # Clear previous paths

        distances = {node["id"]: float("inf") for node in self.nodes}
        distances[self.start_node["id"]] = 0

        visited = set()
        unvisited = set(node["id"] for node in self.nodes)

        previous = {node["id"]: None for node in self.nodes}

        while unvisited:
            current_id = min(unvisited, key=lambda node_id: distances[node_id])
            unvisited.remove(current_id)

            for edge in self.edges:
                if edge["start"]["id"] == current_id and edge["end"]["id"] not in visited:
                    new_dist = distances[current_id] + edge["weight"]
                    if new_dist < distances[edge["end"]["id"]]:
                        distances[edge["end"]["id"]] = new_dist
                        previous[edge["end"]["id"]] = current_id

                if edge["end"]["id"] == current_id and edge["start"]["id"] not in visited:
                    new_dist = distances[current_id] + edge["weight"]
                    if new_dist < distances[edge["start"]["id"]]:
                        distances[edge["start"]["id"]] = new_dist
                        previous[edge["start"]["id"]] = current_id

            visited.add(current_id)

        # Draw paths
        for node_id, dist in distances.items():
            if dist < float("inf") and node_id != self.start_node["id"]:
                path = []
                current = node_id
                while current is not None:
                    path.append(current)
                    current = previous[current]
                path = path[::-1]

                for i in range(len(path) - 1):
                    start_node = next(node for node in self.nodes if node["id"] == path[i])
                    end_node = next(node for node in self.nodes if node["id"] == path[i + 1])
                    self.draw_edge({"start": start_node, "end": end_node, "weight": 0}, color="yellow", display_weight=False)

        messagebox.showinfo("Dijkstra Result", f"Shortest Distances: {distances}")

    def run_hybrid(self):
        """Run a hybrid approach combining ML and Dijkstra."""
        if not self.trained:
            messagebox.showerror("Error", "Train the ML model first!")
            return

        if not self.nodes:
            messagebox.showerror("Error", "No nodes available!")
            return

        if not self.start_node:
            messagebox.showerror("Error", "Set a start node first!")
            return

        self.canvas.delete("path")  # Clear previous paths

        distances = {node["id"]: float("inf") for node in self.nodes}
        distances[self.start_node["id"]] = 0

        visited = set()
        unvisited = set(node["id"] for node in self.nodes)

        previous = {node["id"]: None for node in self.nodes}

        while unvisited:
            current_id = min(unvisited, key=lambda node_id: distances[node_id])
            unvisited.remove(current_id)

            for edge in self.edges:
                start, end = edge["start"], edge["end"]
                if start["id"] == current_id and end["id"] not in visited:
                    # Predict weight using ML
                    predicted_weight = self.model.predict(
                        np.array([[start["x"], start["y"], end["x"], end["y"]]])
                    )[0]
                    new_dist = distances[current_id] + predicted_weight
                    if new_dist < distances[end["id"]]:
                        distances[end["id"]] = new_dist
                        previous[end["id"]] = current_id

                if end["id"] == current_id and start["id"] not in visited:
                    # Predict weight using ML
                    predicted_weight = self.model.predict(
                        np.array([[end["x"], end["y"], start["x"], start["y"]]])
                    )[0]
                    new_dist = distances[current_id] + predicted_weight
                    if new_dist < distances[start["id"]]:
                        distances[start["id"]] = new_dist
                        previous[start["id"]] = current_id

            visited.add(current_id)

        # Draw paths
        for node_id, dist in distances.items():
            if dist < float("inf") and node_id != self.start_node["id"]:
                path = []
                current = node_id
                while current is not None:
                    path.append(current)
                    current = previous[current]
                path = path[::-1]

                for i in range(len(path) - 1):
                    start_node = next(node for node in self.nodes if node["id"] == path[i])
                    end_node = next(node for node in self.nodes if node["id"] == path[i + 1])
                    self.draw_edge({"start": start_node, "end": end_node, "weight": 0}, color="cyan", display_weight=False)

        messagebox.showinfo("Hybrid Result", f"Shortest Distances (Hybrid): {distances}")

    def reset(self):
        """Reset the canvas and all data."""
        self.canvas.delete("all")
        self.nodes.clear()
        self.edges.clear()
        self.start_node = None
        self.trained = False

if __name__ == "__main__":
    root = tk.Tk()
    app = PathComparisonApp(root)
    root.mainloop()
